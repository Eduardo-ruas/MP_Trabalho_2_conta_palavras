var searchData=
[
  ['contarpalavras_3',['contarPalavras',['../classContadorPalavras.html#aa1b45afd9649aa6dceea9eae9269c08d',1,'ContadorPalavras']]]
];
