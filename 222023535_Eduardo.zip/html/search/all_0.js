var searchData=
[
  ['contadorpalavras_0',['ContadorPalavras',['../classContadorPalavras.html',1,'']]],
  ['contarpalavras_1',['contarPalavras',['../classContadorPalavras.html#aa1b45afd9649aa6dceea9eae9269c08d',1,'ContadorPalavras']]]
];
