var searchData=
[
  ['contadorpalavras_2',['ContadorPalavras',['../classContadorPalavras.html',1,'']]]
];
